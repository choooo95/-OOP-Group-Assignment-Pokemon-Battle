package pokemon.model

class Squirtle (_givenName: String, _currentStat: Stat) extends Pokemon (_givenName, _currentStat)

object Squirtle extends PokemonCharacteristics {
  val name = "Squirtle"
  val attack = Array(new Tackle(Attack.basePp), new TailWhip(Attack.basePp))
  val baseStat = new Stat(100, 10, "Grass")
}