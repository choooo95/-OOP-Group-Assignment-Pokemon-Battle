package pokemon.model

abstract class ActiveAttack ( _currentPp: Int ) extends Attack ( _currentPp )