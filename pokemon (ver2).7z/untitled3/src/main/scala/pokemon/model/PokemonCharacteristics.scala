package pokemon.model

trait PokemonCharacteristics {
  val name: String
  val attack: Iterable[Attack]
  val baseStat: Stat
}