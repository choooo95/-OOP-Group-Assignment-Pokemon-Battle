package pokemon.model

class Scratch ( _currentPp: Int ) extends ActiveAttack ( _currentPp )

object Scratch extends ActiveAttackCharacteristics {
  val name = "Scratch"
  val minHpDmg = 20
  val maxHpDmg = 30
}