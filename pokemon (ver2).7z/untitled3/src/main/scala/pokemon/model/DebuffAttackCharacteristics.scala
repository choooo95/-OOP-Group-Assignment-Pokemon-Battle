package pokemon.model

trait DebuffAttackCharacteristics extends AttackCharacteristics {
  val defDmg: Int
}