package pokemon.model

class TailWhip ( _currentPp: Int ) extends DebuffAttack ( _currentPp )

object TailWhip extends DebuffAttackCharacteristics {
  val name = "TailWhip"
  val defDmg = 3
}