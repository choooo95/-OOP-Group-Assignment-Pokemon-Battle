package pokemon.model

class Charmander (_givenName: String, _currentStat: Stat) extends Pokemon (_givenName, _currentStat)

object Charmander extends PokemonCharacteristics {
  val name = "Charmander"
  val attack = Array(new Scratch(Attack.basePp), new Growl(Attack.basePp))
  val baseStat = new Stat(100, 10, "Grass")
}