package pokemon.model

class Growl ( _currentPp: Int ) extends DebuffAttack ( _currentPp )

object Growl extends DebuffAttackCharacteristics {
  val name = "Growl"
  val defDmg = 2
}