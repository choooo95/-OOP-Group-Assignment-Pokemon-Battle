package pokemon.model

abstract class DebuffAttack ( _currentPp: Int ) extends Attack ( _currentPp )