package pokemon.model

trait ActiveAttackCharacteristics extends AttackCharacteristics {
  val minHpDmg: Int
  val maxHpDmg: Int
}