package pokemon.model

class Bulbasaur (_givenName: String, _currentStat: Stat) extends Pokemon (_givenName, _currentStat)

object Bulbasaur extends PokemonCharacteristics {
  val name = "Bulbasaur"
  val attack = Array(new Growl(Attack.basePp), new Tackle(Attack.basePp))
  val baseStat = new Stat(100, 10, "Grass")
}