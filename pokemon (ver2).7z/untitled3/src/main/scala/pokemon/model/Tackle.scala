package pokemon.model

class Tackle ( _currentPp: Int ) extends ActiveAttack ( _currentPp )

object Tackle extends ActiveAttackCharacteristics {
  val name = "Tackle"
  val minHpDmg = 25
  val maxHpDmg = 30
}