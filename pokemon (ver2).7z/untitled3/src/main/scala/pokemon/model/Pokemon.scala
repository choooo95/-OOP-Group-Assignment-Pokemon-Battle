package pokemon.model

case class Stat ( hp: Int, defense: Int, element: String )

abstract class Pokemon ( val givenName: String, var currentStat: Stat )