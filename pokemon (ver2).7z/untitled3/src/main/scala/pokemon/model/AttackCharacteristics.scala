package pokemon.model

trait AttackCharacteristics {
  val name: String
}