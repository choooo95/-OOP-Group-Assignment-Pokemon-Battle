package pokemon.model

abstract class Attack ( var currentPp: Int )

object Attack {
  val basePp = 10
}